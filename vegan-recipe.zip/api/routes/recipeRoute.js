const express = require('express');

const recipeController = require('../controllers/recipeController');

const router = express.Router();

router
  .route('/')
  .get(recipeController.getAllRecipes)
  .post(recipeController.manageImage, recipeController.createRecipe);
router
  .route('/:id')
  .get(recipeController.getRecipe)
  .patch(recipeController.manageImage, recipeController.updateRecipe)
  .delete(recipeController.deleteRecipe);

module.exports = router;
